<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Arta extends Model
{
    public function home() {
        $sliders = Slider::all();
        $posts = Arta::all();
        $tags = Tag::all();

        echo json_encode([
            "result" => "",
            "extra" => "",
            "message" => [
                "tags" => $tags,
                "posts" => $posts,
                "slider" => $sliders
            ]
        ]);
    }
}
