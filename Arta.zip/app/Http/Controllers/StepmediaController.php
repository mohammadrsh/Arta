<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StepmediaController extends Controller
{
    //
}
